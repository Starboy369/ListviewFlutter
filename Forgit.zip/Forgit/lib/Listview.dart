import 'package:flutter/material.dart';

class B2ListView extends StatefulWidget {
  B2ListView({Key key}) : super(key: key);

  @override
  _B2ListViewState createState() => _B2ListViewState();
}

class _B2ListViewState extends State<B2ListView> {
  int id = 1;
  List<String> List1 = [
    "Jan",
    "Feb",
    "Mar",
    "Apr",
    "May",
    "June",
    "July",
    "Aug",
    "Sep",
    "Oct",
    "Nov",
    "Dec"
  ];
  List<String> List2 = [
    "Sunday",
    "Monday",
    "Tuesday",
    "Wednesday",
    "Thursday",
    "Friday",
    "Saturday"
  ];
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          title: Text("List View"),
        ),
        body: SafeArea(
          top: false,
          bottom: false,
          child: ListView(
            children: <Widget>[
              Row(
                children: <Widget>[
                  MaterialButton(
                    child: Text(
                      "List 1",
                      style:
                          TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                    ),
                    onPressed: () {
                      setState(() {
                        id = 1;
                      });
                    },
                    color: Colors.amberAccent,
                  ),
                  MaterialButton(
                    child: Text(
                      "List 2",
                      style:
                          TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                    ),
                    onPressed: () {
                      setState(() {
                        id = 2;
                      });
                    },
                    color: Colors.blueAccent,
                  )
                ],
              ),
              Row(
                children: <Widget>[
                  Expanded(
                    child: SizedBox(
                      height: 570,
                      child: DynamicListView(),
                    ),
                  )
                ],
              )
            ],
          ),
        ),
      ),
    );
  }

  Widget DynamicListView() {
    if (id == 1) {
      return List1view();
    }

    if (id == 2) {
      return List2view();
    }
  }

  Widget List1view() {
    return ListView.builder(
      itemCount: List1.length,
      itemBuilder: (context, index) {
        return Card(
          child: Text(
            List1[index],
            style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20),
          ),
        );
      },
    );
  }

  Widget List2view() {
    return ListView.builder(
      itemCount: List2.length,
      itemBuilder: (context, index) {
        return Card(
          child: Text(List2[index],
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20)),
        );
      },
    );
  }
}
